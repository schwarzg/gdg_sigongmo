### Step 1. 모듈 가지고 오기
import numpy as np  # Array 관련 함수
import about_music as AM # 음악과 관련된 라이브러리 호출
import about_data as AD # 데이터 처리와 관련된 라이브러리 호출
from tensorflow.python import  keras as K  # Tensorflow 안의 keras 관련 함수

######## A: 만든 노래 데이터들를 통해서 노래 선정하기
######## B: 제공받은 음원 파일(mid)을 통해서 노래 선정하기
### Step 2.A. 학습할 노래 선정하기
input_fname, output_fname, slected_seq = AM.Music_code(0)  # 0: 나비야, 1: 들장미소녀캔디, 2: 사랑을 했다

#### Step 2.B. 제공되는 음원 파일 로드 및 시퀀스 데이터로 만들기
# # 제공되는 음원 파일 로드하기
# fname = 'music_collection/dean-what2do.mid' # 'music_collection/twice-knock_knock.mid'
# input_fname, output_fname, midi = AM.Make_fname(fname)
# # 학습할 음악을 데이터 만들기
# slected_seq = AM.Make_notes(midi)

### Step 3. 단어장 만들기
code2idx, idx2code, output_size = AD.Make_vocabuluary(slected_seq)

### Step 4. 데이터 셋 생성하기
window_size = 5
input_size = window_size - 1
data_set = AD.Seq2data(slected_seq, window_size, code2idx)  # data_set의 값들은 int 값

### Step 5. 입력과 출력 데이터 셋 추출하기
x_train, y_train, = AD.Separate_X_and_Y(data_set, input_size, output_size)

'''  코드를 작성하세요  '''
### Step 6. 모델 만들기
# 모델 만들기

# 모델 학습 설정하기



### Step 7. 학습하기




### Step 8. 예측하기
# 예측에 들어갈 시퀀스(seq_in) 초기 배열 만들기

# 예측된 시퀀스(seq_out) 초기 배열 만들기

# 노래 예측하기


'''  코드를 작성 끝  '''

### Step 9. 선택/학습된 노래에 음과 박자 데이터 추출하기
slected_seq_notes_and_notelen = AM.Separate_note_and_length(slected_seq)  # 선택된 노래
predicted_seq_notes_and_notelen= AM.Separate_note_and_length(predicted_seq)  # 학습된 노래

### Step10. 선택된 노래와 학습된 노래 음원 파일과 악보 저장하기
selected_score = AM.MAKE_SCORE(slected_seq_notes_and_notelen, input_fname)  # 선택된 노래
selected_score.Make_score() # 선택된 악보 작곡 및 음악 파일 저장
predicted_score = AM.MAKE_SCORE(predicted_seq_notes_and_notelen, output_fname)  # 학습된 노래
predicted_score.Make_score() # 학습된 악보 작곡 및 음악 파일 저장
